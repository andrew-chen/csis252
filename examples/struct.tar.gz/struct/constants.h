#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

const int arraymax = 20;

#endif
