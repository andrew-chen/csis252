#ifndef _PROTOTYPES_H_
#define _PROTOTYPES_H_

#include "personType.h"

void sort(personType people[],int count);
void input(personType people[],int& count);
void output(const personType people[],int count);

#endif
