#ifndef _PERSONTYPE_H_
#define _PERSONTYPE_H_

#include <string>
using namespace std;

struct personType
{
   string name;
   int month;
   int day;
   int year;
};

#endif
