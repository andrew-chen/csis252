#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

const int arraysize = 20;

#endif
