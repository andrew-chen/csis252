const int arraysize=100;
const int sentinel=-1;
