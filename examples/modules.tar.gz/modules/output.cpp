#include <iostream>
using namespace std;

void output(const int array[],int n)
{
   for (int i=0; i<n; i++)
      cout << array[i] << ' ';
   cout << endl;
}
