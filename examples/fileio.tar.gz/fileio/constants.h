const int arraysize=10;
